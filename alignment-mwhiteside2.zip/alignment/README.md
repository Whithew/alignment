Download the files found at https://github.com/dmit1529/alignment.

Bring in the principle of alignment to the small form and all the content included for a basic login page. Use text alignment and columns to play with mixed alignment with strong edges. Every element on the page should be aligned with something else on the page. 

In the online text area, give a short explanation of which elements are aligned the same. What goes together? There should be no black sheep elements.

When finished rename the project folder to alignment-username, zip up the folder and upload to Moodle for submission. Be sure to include your short explanation in the online text area. Late submissions will not be accepted for marking.
